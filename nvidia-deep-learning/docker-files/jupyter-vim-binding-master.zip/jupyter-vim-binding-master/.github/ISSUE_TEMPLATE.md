### Summary


### Environment

- [ ] Operating system : (e.g. Ubuntu Gnome 15.04 64bit)
- [ ] Web browser : (e.g. Firefox 44.0.2)
- [ ] Version or revision of Jupyter Notebook : (e.g. 4.1 or 620fb29)
- [ ] Revision of jupyter-vim-binding : (e.g. 5a057d6)


### Behavior

#### Expected

#### Actual


### Step by step procedure

1. Start local Jupyter Notebook by `jupyter notebook`
2. Access http://localhost:8888/
3. etc.


### What you have done to solve the issue

For example, the behavior is confirmed with Firefox 44.0.2 and Google Chrome xx.xx.xx and could not be reproduced in Firefox but Chrome or what ever.


### Remarks

If any
